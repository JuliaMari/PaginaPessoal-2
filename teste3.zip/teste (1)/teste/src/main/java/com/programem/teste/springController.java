package com.programem.teste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@Controller
public class springController {
    @GetMapping ("/pagina")
    public String pagina(){
        return "pagina";
    }
}